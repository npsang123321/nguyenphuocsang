<?
#thời gian load lại số user đang chat
$config['refresh_online'] = 15; //15s
#thời gian load lại nội dung chat
$config['refresh_content'] = 10; //15s

$config['chatline'] = 30;  // số dòng hiển thị trong khung chat
$config['onlstats'] = 15;// thống kê online trong vòng 15 phút
$config['admin'] = array('Admin','Chip');

?>